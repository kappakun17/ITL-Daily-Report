from django.apps import AppConfig


class dialyConfig(AppConfig):
    name = 'dialy'
