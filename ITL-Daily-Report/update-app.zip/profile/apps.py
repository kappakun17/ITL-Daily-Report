from django.apps import AppConfig


class profileConfig(AppConfig):
    name = 'profile'
