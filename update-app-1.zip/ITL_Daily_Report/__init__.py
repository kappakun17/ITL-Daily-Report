"""
Package for ITL_Daily_Report.
"""
