from django.apps import AppConfig


class homeConfig(AppConfig):
    name = 'home'
