from django.apps import AppConfig


class scheduleConfig(AppConfig):
    name = 'schedule'
