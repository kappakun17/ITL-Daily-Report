from django.apps import AppConfig


class userConfig(AppConfig):
    name = 'user'
