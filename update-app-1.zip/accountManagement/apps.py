from django.apps import AppConfig


class accountManagementConfig(AppConfig):
    name = 'accountManagement'
